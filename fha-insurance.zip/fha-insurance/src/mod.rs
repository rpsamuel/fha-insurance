pub mod insurance_policy;
pub use insurance_policy::{InsurancePolicy, PolicyStatus};

pub mod claim;
pub use claim::{InsuranceClaim, ClaimStatus};

pub mod blockchain;
pub use blockchain::{Blockchain, Block};
