use fha_insurance::blockchain::{Blockchain, Block};
use fha_insurance::claim::{ClaimStatus, InsuranceClaim};
use fha_insurance::policy::InsurancePolicy;
use std::io::{stdin, stdout, Write};

fn main() {
    let mut blockchain = Blockchain::new();

    let borrower_name = String::from("John Smith");
    let property_address = String::from("123 Main St.");
    let premium_amount = 100.0;
    let policy_id = blockchain.add_block(InsurancePolicy::new(
        borrower_name.clone(),
        property_address.clone(),
        premium_amount,
    ));

    let mortgage_holder_name = String::from("ABC Bank");
    let claim_id = blockchain.add_block(InsuranceClaim::new(
        policy_id,
        mortgage_holder_name.clone(),
        ClaimStatus::Filed,
        0,
        0,
    ));

    let mut input = String::new();

    println!("Welcome to the FHA Insurance System!");

    loop {
        println!("\nPlease select an option:");
        println!("1. File a new insurance claim");
        println!("2. Check the status of an existing claim");
        println!("3. Exit");

        input.clear();
        print!("> ");
        let _ = stdout().flush();

        stdin().read_line(&mut input).unwrap();
        let choice = input.trim().parse::<u32>().unwrap();

        match choice {
            1 => {
                let policy_id = policy_id.clone();

                println!("Please enter your name:");
                input.clear();
                print!("> ");
                let _ = stdout().flush();

                stdin().read_line(&mut input).unwrap();
                let mortgage_holder_name = input.trim().to_string();

                let date_applied = 0;
                let date_payable = 0;
                let claim_id = blockchain.add_block(InsuranceClaim::new(
                    policy_id,
                    mortgage_holder_name,
                    ClaimStatus::Filed,
                    date_applied,
                    date_payable,
                ));

                println!(
                    "Your claim has been filed. Your claim ID is {}",
                    claim_id
                );
            }
            2 => {
                println!("Please enter your claim ID:");
                input.clear();
                print!("> ");
                let _ = stdout().flush();

                stdin().read_line(&mut input).unwrap();
                let claim_id = input.trim().parse::<usize>().unwrap();

                match blockchain.get_block(claim_id) {
                    Some(Block::Claim(claim)) => {
                        println!("Mortgage Holder Name: {}", claim.mortgage_holder_name);
                        println!("Claim Date: {}", claim.claim_date);
                        println!("Claim Status: {:?}", claim.claim_status);
                    }
                    _ => println!("Claim not found"),
                };
            }
            3 => break,
            _ => println!("Invalid option, please try again"),
        }
    }

    println!("Thank you for using the FHA Insurance System!");
}
