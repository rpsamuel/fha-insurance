use crate::{Blockchain, InsurancePolicy, InsuranceClaim, ClaimStatus};

pub fn run() {
    let mut blockchain = Blockchain::new();

    let policy_id = blockchain.add_block(InsurancePolicy::new(
        "John Doe".to_string(),
        false,
        1647830400, // April 20, 2022
    ));

    let claim_id = blockchain.add_block(InsuranceClaim::new(
        policy_id,
        1648916800, // April 31, 2022 (invalid date, will be rejected)
        0, // no payable date yet
        "Jane Doe".to_string(),
        ClaimStatus::Pending,
    ));

    match blockchain.get_block(claim_id) {
        Some(Block::Claim(claim)) => {
            match blockchain.get_block(claim.policy_id) {
                Some(Block::Policy(policy)) => {
                    if !claim.is_valid() {
                        println!("Invalid claim: {:?}", claim);
                    } else {
                        println!("Valid claim: {:?}", claim);
                        blockchain.update_block(claim_id, InsuranceClaim {
                            date_payable: 1649185600, // May 5, 2022
                            ..claim
                        });
                        println!("Updated claim: {:?}", blockchain.get_block(claim_id).unwrap());
                    }
                },
                _ => println!("Error: policy not found"),
            }
        },
        _ => println!("Error: claim not found"),
    }
}
