use crate::ClaimStatus;
pub struct InsuranceClaim {
    claim_id: u64,
    policy_id: u64,
    claim_date: i64,
    date_payable: i64,
    mortgage_holder_name: String,
    claim_status: ClaimStatus,
}

impl InsuranceClaim {
    pub fn new(
        claim_id: u64,
        policy_id: u64,
        claim_date: i64,
        date_payable: i64,
        mortgage_holder_name: String,
        claim_status: ClaimStatus,
    ) -> Self {
        Self {
            claim_id,
            policy_id,
            claim_date,
            date_payable,
            mortgage_holder_name,
            claim_status,
        }
    }
}
