use crate::InsurancePolicy;
use crate::InsuranceClaim;
pub enum Block {
    Policy(InsurancePolicy),
    Claim(InsuranceClaim),
}

impl Block {
    pub fn new_policy(policy: InsurancePolicy) -> Self {
        Self::Policy(policy)
    }

    pub fn new_claim(claim: InsuranceClaim) -> Self {
        Self::Claim(claim)
    }
}
