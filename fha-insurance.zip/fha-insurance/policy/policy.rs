pub struct InsurancePolicy {
    borrower_name: String,
    claim_history: bool,
    expiration_date: i64,
}

impl InsurancePolicy {
    pub fn new(borrower_name: String, claim_history: bool, expiration_date: i64) -> Self {
        Self {
            borrower_name,
            claim_history,
            expiration_date,
        }
    }
}
